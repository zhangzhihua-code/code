%%����ϵͳ��Ϣ��
clc
clear
% load_data1=load('mtl_yuce_cpu_ram_172.mat');%%CPU+RAM
load_data2=load('Yuce_wjl_dbl.mat');%%CPU\RAM\IO
load_data3=load('mtl_yuce_cpu_ram_io_ioTime_172.mat');%%CPU+RAM+io+ioTime
load_data4 = load('mtl_yuce_CRDIC_172.mat');
load_data5 = load('mtl_yuce_CRDICM_172.mat');
% load_data6 = load('mtl_yuce_CRDICMM_172.mat');
% load_data7 = load('mtl_yuce_CRT_172.mat');
% load_data8 = load('mtl_yuce_CRTA_172.mat');
% load_data9 = load('mtl_yuce_CRDICMMM_172.mat');

% Ycpu_ram = load_data1.Ypre_sum;
Ycpu_ram_io = load_data2.Ypre_sum;
Ycpu_ram_io_ioTime = load_data3.Ypre_sum;
Ycrdic = load_data4.Ypre_sum;
Ycrdicm = load_data5.Ypre_sum;
% Ycrdicmm = load_data6.Ypre_sum;
% Ycrt = load_data7.Ypre_sum;
% Ycrta = load_data8.Ypre_sum;
% Ycrdicmmm = load_data9.Ypre_sum;

% load_data11=load('mtl_true_cpu_ram_172.mat');%%CPU+RAM
load_data22=load('True_wjl_dbl.mat');%%CPU\RAM\IO
load_data33=load('mtl_true_cpu_ram_io_ioTime_172.mat');%%CPU+RAM+io+ioTime
load_data44 = load('mtl_true_CRDIC_172.mat');
load_data55 = load('mtl_true_CRDICM_172.mat');
% load_data66 = load('mtl_true_CRDICMM_172.mat');
% load_data77 = load('mtl_true_CRT_172.mat');
% load_data88 = load('mtl_true_CRTA_172.mat');
% load_data99 = load('mtl_true_CRDICMMM_172.mat');

% Tcpu_ram = load_data11.Ytest_sum;
Tcpu_ram_io = load_data22.Ytest_sum;
Tcpu_ram_io_ioTime = load_data33.Ytest_sum;
Tcrdic = load_data44.Ytest_sum;
Tcrdicm = load_data55.Ytest_sum;
% Tcrdicmm = load_data66.Ytest_sum;
% Tcrt = load_data77.Ytest_sum;
% Tcrta = load_data88.Ytest_sum;
% Tcrdicmmm = load_data99.Ytest_sum;

% duan1 = 13;
% % for i=1:104
% i=1;
% rmse_CR(1,i)=RMSE(Ycpu_ram(i,1:100)',Tcpu_ram(i,1:100)');
% rmse_CRD(1,i)=RMSE(Ycpu_ram_io (i,1:100)',Tcpu_ram_io (i,1:100)');
% rmse_CRDT(1,i)=RMSE(Ycpu_ram_io_ioTime(i,1:100)',Tcpu_ram_io_ioTime(i,1:100)');
% rmse_CRDTC(1,i)=RMSE(Ycrdic(i,1:100)',Tcrdic(i,1:100)');
% rmse_CRDTCM(1,i)=RMSE(Ycrdicm(i,1:100)',Tcrdicm(i,1:100)');
% rmse_CRDTCMM(1,i)=RMSE(Ycrdicmm(i,1:100)',Tcrdicmm(i,1:100)');
% rmse_CRT(1,i)=RMSE(Ycrt(i,1:100)',Tcrt(i,1:100)');
% 
% mae_CR(1,i)=RMSE(Ycpu_ram(i,1:100)',Tcpu_ram(i,1:100)');
% mae_CRD(1,i)=RMSE(Ycpu_ram_io (i,1:100)',Tcpu_ram_io (i,1:100)');
% mae_CRDT(1,i)=RMSE(Ycpu_ram_io_ioTime(i,1:100)',Tcpu_ram_io_ioTime(i,1:100)');
% mae_CRDTC(1,i)=RMSE(Ycrdic(i,1:100)',Tcrdic(i,1:100)');
% mae_CRDTCM(1,i)=RMSE(Ycrdicm(i,1:100)',Tcrdicm(i,1:100)');
% mae_CRDTCMM(1,i)=RMSE(Ycrdicmm(i,1:100)',Tcrdicmm(i,1:100)');
% mae_CRT(1,i)=RMSE(Ycrt(i,1:100)',Tcrt(i,1:100)');
% 
% mre_CR(1,i)=RMSE(Ycpu_ram(i,1:100)',Tcpu_ram(i,1:100)');
% mre_CRD(1,i)=RMSE(Ycpu_ram_io (i,1:100)',Tcpu_ram_io (i,1:100)');
% mre_CRDT(1,i)=RMSE(Ycpu_ram_io_ioTime(i,1:100)',Tcpu_ram_io_ioTime(i,1:100)');
% mre_CRDTC(1,i)=RMSE(Ycrdic(i,1:100)',Tcrdic(i,1:100)');
% mre_CRDTCM(1,i)=RMSE(Ycrdicm(i,1:100)',Tcrdicm(i,1:100)');
% mre_CRDTCMM(1,i)=RMSE(Ycrdicmm(i,1:100)',Tcrdicmm(i,1:100)');
% mre_CRT(1,i)=RMSE(Ycrt(i,1:100)',Tcrt(i,1:100)');
% 
% smape_CR(1,i)=RMSE(Ycpu_ram(i,1:100)',Tcpu_ram(i,1:100)');
% smape_CRD(1,i)=RMSE(Ycpu_ram_io (i,1:100)',Tcpu_ram_io (i,1:100)');
% smape_CRDT(1,i)=RMSE(Ycpu_ram_io_ioTime(i,1:100)',Tcpu_ram_io_ioTime(i,1:100)');
% smape_CRDTC(1,i)=RMSE(Ycrdic(i,1:100)',Tcrdic(i,1:100)');
% smape_CRDTCM(1,i)=RMSE(Ycrdicm(i,1:100)',Tcrdicm(i,1:100)');
% smape_CRDTCMM(1,i)=RMSE(Ycrdicmm(i,1:100)',Tcrdicmm(i,1:100)');
% smape_CRT(1,i)=RMSE(Ycrt(i,1:100)',Tcrt(i,1:100)');
% 
% % end


for i=1:80
% i=1;
% rmse_(1,1)=RMSE(Ycpu_ram(i,1:100)',Tcpu_ram(i,1:100)');
rmse_(1,2)=RMSE(Ycpu_ram_io (i,1:100)',Tcpu_ram_io (i,1:100)');
rmse_(1,3)=RMSE(Ycpu_ram_io_ioTime(i,1:100)',Tcpu_ram_io_ioTime(i,1:100)');
rmse_(1,4)=RMSE(Ycrdic(i,1:100)',Tcrdic(i,1:100)');
rmse_(1,5)=RMSE(Ycrdicm(i,1:100)',Tcrdicm(i,1:100)');
% rmse_(1,6)=RMSE(Ycrdicmm(i,1:100)',Tcrdicmm(i,1:100)');
% rmse_(1,7)=RMSE(Ycrt(i,1:100)',Tcrt(i,1:100)');
% rmse_(1,8)=RMSE(Ycrta(i,1:100)',Tcrta(i,1:100)');
% rmse_(1,9)=RMSE(Ycrdicmmm(i,1:100)',Tcrdicmmm(i,1:100)');

% mae_(1,1)=MAE(Ycpu_ram(i,1:100)',Tcpu_ram(i,1:100)');
mae_(1,2)=MAE(Ycpu_ram_io (i,1:100)',Tcpu_ram_io (i,1:100)');
mae_(1,3)=MAE(Ycpu_ram_io_ioTime(i,1:100)',Tcpu_ram_io_ioTime(i,1:100)');
mae_(1,4)=MAE(Ycrdic(i,1:100)',Tcrdic(i,1:100)');
mae_(1,5)=MAE(Ycrdicm(i,1:100)',Tcrdicm(i,1:100)');
% mae_(1,6)=MAE(Ycrdicmm(i,1:100)',Tcrdicmm(i,1:100)');
% mae_(1,7)=MAE(Ycrt(i,1:100)',Tcrt(i,1:100)');
% mae_(1,8)=MAE(Ycrta(i,1:100)',Tcrta(i,1:100)');
% mae_(1,9)=MAE(Ycrdicmmm(i,1:100)',Tcrdicmmm(i,1:100)');

% mre_(1,1)=MRE(Ycpu_ram(i,1:100)',Tcpu_ram(i,1:100)');
mre_(1,2)=MRE(Ycpu_ram_io (i,1:100)',Tcpu_ram_io (i,1:100)');
mre_(1,3)=MRE(Ycpu_ram_io_ioTime(i,1:100)',Tcpu_ram_io_ioTime(i,1:100)');
mre_(1,4)=MRE(Ycrdic(i,1:100)',Tcrdic(i,1:100)');
mre_(1,5)=MRE(Ycrdicm(i,1:100)',Tcrdicm(i,1:100)');
% mre_(1,6)=MRE(Ycrdicmm(i,1:100)',Tcrdicmm(i,1:100)');
% mre_(1,7)=MRE(Ycrt(i,1:100)',Tcrt(i,1:100)');
% mre_(1,8)=MRE(Ycrta(i,1:100)',Tcrta(i,1:100)');
% mre_(1,9)=MRE(Ycrdicmmm(i,1:100)',Tcrdicmmm(i,1:100)');

% smape_(1,1)=SMAPE(Ycpu_ram(i,1:100)',Tcpu_ram(i,1:100)');
smape_(1,2)=SMAPE(Ycpu_ram_io (i,1:100)',Tcpu_ram_io (i,1:100)');
smape_(1,3)=SMAPE(Ycpu_ram_io_ioTime(i,1:100)',Tcpu_ram_io_ioTime(i,1:100)');
smape_(1,4)=SMAPE(Ycrdic(i,1:100)',Tcrdic(i,1:100)');
smape_(1,5)=SMAPE(Ycrdicm(i,1:100)',Tcrdicm(i,1:100)');
% smape_(1,6)=SMAPE(Ycrdicmm(i,1:100)',Tcrdicmm(i,1:100)');
% smape_(1,7)=SMAPE(Ycrt(i,1:100)',Tcrt(i,1:100)');
% smape_(1,8)=SMAPE(Ycrta(i,1:100)',Tcrta(i,1:100)');
% smape_(1,9)=SMAPE(Ycrdicmmm(i,1:100)',Tcrdicmmm(i,1:100)');

A(:,1)=rmse_(2:5)';A(:,2)=mae_(2:5)';A(:,3)=mre_(2:5)';A(:,4)=smape_(2:5)';
for i2=1:4
    for i3=1:4
        B(i3,i2)=A(i3,i2)/sum(A(:,i2));
    end
end

S = [];
for j=1:4
    s=[];
    for k=1:4
       s(1,k)=-(B(j,k)*log2(B(j,k)));
    end
    S(1,j)=sum(s);
end
  SS(i,:)=S;
end

meanSS=mean(SS);
 
for e1=1:size(SS,1)
   I=[];
   index=[];
    [I,index]=sort(SS(e1,:));
    Index(e1,:)=index;
end
for e2=1:4
  res=[];
    res = tabulate(Index(:,e2));
        b{1,e2}=sortrows(res,2);
    c(e2,:)=b{1,e2}(end,:);
end
