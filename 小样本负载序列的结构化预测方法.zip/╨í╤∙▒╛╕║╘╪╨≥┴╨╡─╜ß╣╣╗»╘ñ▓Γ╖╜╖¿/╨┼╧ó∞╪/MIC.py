# -*- coding: utf-8 -*-
"""
Created on Fri Mar 13 09:02:24 2020

@author: Administrator
最大互信息系数
"""

import numpy as np
from minepy import MINE
import scipy.io as sio
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

##-----------------------单个任务--------------------------------------
#X3=sio.loadmat('./cpu_ram_io_ioTime.mat')##不是预测值，是原始值
#dataC = X3['cpu_ram_io_ioTime']
#X3=sio.loadmat('./cpu_ram_io_ioTime.mat')##不是预测值，是原始值
#dataC = X3['cpu_ram_io_ioTime']
X3=sio.loadmat('./task30_dbl_CRDICM_yValue.mat')##CPU\RAM\IO\IOtime\C\M///100个任务中的第30个
dataC = X3['task30_dbl']
dataB = dataC[:len(dataC)-1,:]

def MIC_matirx(dataframe, mine):
    data = np.array(dataframe)
    n = len(data[0,:])
    result = np.zeros([n, n])
    for i in range(n):
        for j in range(n):
            mine.compute_score(data[:, i], data[:, j])
            result[i, j] = mine.mic()
            result[j, i] = mine.mic()
    RT = pd.DataFrame(result)
    return RT
mine = MINE(alpha=0.75, c=5)
data_wine_mic = MIC_matirx(dataB,mine)

def ShowHeatMap(DataFrame):
    colormap = plt.cm.RdBu
    ylabels = DataFrame.columns.values.tolist()
    f, ax = plt.subplots(figsize=(14, 14))
    ax.set_title('GRA HeatMap')
    sns.heatmap(DataFrame.astype(float),
                cmap=colormap,
                ax=ax,
                annot=True,
                yticklabels=ylabels,
                xticklabels=ylabels)
    plt.show()
ShowHeatMap(data_wine_mic)
##-----------------------单个任务--------------------------------------

'''
##-------------------100个任务--------------------------------------

X3=sio.loadmat('./alldata_172_100.mat')##不是预测值，是原始值
dataC = X3['alldata']

def MIC_matirx(dataframe, mine):
    data = np.array(dataframe)
    n = len(data[0,:])
    result = np.zeros([n, n])
    for i in range(n):
        for j in range(n):
            mine.compute_score(data[:, i], data[:, j])
            result[i, j] = mine.mic()
            result[j, i] = mine.mic()
    RT = pd.DataFrame(result)
    return RT

def ShowHeatMap(DataFrame):
    colormap = plt.cm.RdBu
    ylabels = DataFrame.columns.values.tolist()
    f, ax = plt.subplots(figsize=(14, 14))
    ax.set_title('GRA HeatMap')
    sns.heatmap(DataFrame.astype(float),
                cmap=colormap,
                ax=ax,
                annot=True,
                yticklabels=ylabels,
                xticklabels=ylabels)
    plt.show()

dataD = dataC[:,348:353]
dataE = dataC[:,357]
dataF = np.c_[dataD,dataE]
#row1 = 12
#row2 = 18
#mic_all = []
for i in range(1):
    dataB = []
#    dataB = dataC[:len(dataC)-1,row1:row2]
    dataB = dataF
    mine = MINE(alpha=0.75, c=5)
    data_wine_mic = MIC_matirx(dataB,mine)
    a = np.argsort(np.array(data_wine_mic))##正序
#    mic_all.append(a[1,:])
    ShowHeatMap(pd.DataFrame(data_wine_mic))
#    row1 = row1 + 12
#    row2 = row2 + 12

#sio.savemat('mic_all_io2.mat',{"mic_all_io2":mic_all})
##-------------------100个任务--------------------------------------
'''